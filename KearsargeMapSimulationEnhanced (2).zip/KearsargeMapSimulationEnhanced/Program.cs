﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace KearsargeMapSimulationEnhanced
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Start with the intro form (basic version)
            Application.Run(new IntroForm());
        }
    }

    // =====================================================
    // FIRST FORM - INTRO SCREEN (Basic Overview Simulation)
    // =====================================================
    public class IntroForm : Form
    {
        private Panel displayPanel;
        private Label displayLabel;
        private Button btnHangar, btnCommand, btnMedical, btnMess, btnQuarters, btnEngine;
        private Button btnLaunchFullGUI;

        public IntroForm()
        {
            this.Text = "USS Kearsarge - Basic Simulation";
            this.Size = new Size(800, 500);
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Main display area panel
            displayPanel = new Panel
            {
                Size = new Size(580, 400),
                Location = new Point(180, 20),
                BorderStyle = BorderStyle.Fixed3D
            };

            // Label to show simulation details
            displayLabel = new Label
            {
                AutoSize = false,
                Size = displayPanel.Size,
                Font = new Font("Consolas", 10),
                TextAlign = ContentAlignment.TopLeft
            };
            displayPanel.Controls.Add(displayLabel);

            // Create buttons for each section
            btnHangar = CreateButton("Hangar Bay", 20, 20, ShowHangar);
            btnCommand = CreateButton("Command Center", 20, 70, ShowCommand);
            btnMedical = CreateButton("Medical Bay", 20, 120, ShowMedical);
            btnMess = CreateButton("Mess Decks", 20, 170, ShowMess);
            btnQuarters = CreateButton("Sleeping Quarters", 20, 220, ShowQuarters);
            btnEngine = CreateButton("Engine Room", 20, 270, ShowEngine);

            // Button to launch enhanced GUI
            btnLaunchFullGUI = new Button
            {
                Text = "▶ Launch Full Simulation",
                Size = new Size(150, 40),
                Location = new Point(20, 350),
                BackColor = Color.LightGreen
            };
            btnLaunchFullGUI.Click += (s, e) =>
            {
                // Pass a reference to this form to MainForm for Back navigation
                new MainForm(this).Show();
                this.Hide(); // Hide the intro form
            };

            // Add all controls to form
            this.Controls.AddRange(new Control[]
            {
                btnHangar, btnCommand, btnMedical,
                btnMess, btnQuarters, btnEngine,
                btnLaunchFullGUI, displayPanel
            });
        }

        // Helper method to create buttons
        private Button CreateButton(string text, int x, int y, EventHandler handler)
        {
            var button = new Button
            {
                Text = text,
                Size = new Size(150, 40),
                Location = new Point(x, y)
            };
            button.Click += handler;
            return button;
        }

        // Basic room display content
        private void ShowHangar(object sender, EventArgs e) =>
            displayLabel.Text = "🚁 Hangar Bay\n\n- Helicopters and Harriers ready for deployment.";

        private void ShowCommand(object sender, EventArgs e) =>
            displayLabel.Text = "🧭 Command Center\n\n- Tactical systems green.\n- DEFCON 5 readiness.";

        private void ShowMedical(object sender, EventArgs e) =>
            displayLabel.Text = "🩺 Medical Bay\n\n- Equipment: X-Ray, Trauma kits, Defibrillators.";

        private void ShowMess(object sender, EventArgs e) =>
            displayLabel.Text = "🍽️ Mess Decks\n\n- Breakfast: 0600-0800\n- Lunch: 1200-1400\n- Dinner: 1800-2000.";

        private void ShowQuarters(object sender, EventArgs e) =>
            displayLabel.Text = "🛏️ Sleeping Quarters\n\n- Officers and enlisted berthing.\n- Occupancy: 87%";

        private void ShowEngine(object sender, EventArgs e) =>
            displayLabel.Text = "⚙️ Engine Room\n\n- Steam Turbines operational\n- Fuel Level: 67%";
    }

    // ===========================================================
    // SECOND FORM - ENHANCED SIMULATION WITH INTERACTIVE CONTROLS
    // ===========================================================
    public class MainForm : Form
    {
        private Form introFormRef; // Reference to go back
        private Panel mainPanel;
        private Label displayLabel;
        private Button btnHangar, btnBack;
        private RadioButton radioNormal, radioCombat;
        private CheckBox chkXRay, chkDefib, chkTrauma;
        private ComboBox cmbMealTime;
        private TrackBar trackOccupancy;
        private ProgressBar progressFuel;

        public MainForm(Form introForm)
        {
            this.introFormRef = introForm;
            this.Text = "USS Kearsarge (LHD-3) Enhanced Interior Simulation";
            this.Size = new Size(900, 600);
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Main panel for displaying content
            mainPanel = new Panel
            {
                Size = new Size(580, 400),
                Location = new Point(290, 20),
                BorderStyle = BorderStyle.Fixed3D
            };
            displayLabel = new Label
            {
                AutoSize = false,
                Size = mainPanel.Size,
                Font = new Font("Consolas", 11),
                TextAlign = ContentAlignment.TopLeft
            };
            mainPanel.Controls.Add(displayLabel);

            // GUI Components
            btnHangar = new Button { Text = "🛫 Hangar Bay", Size = new Size(260, 40), Location = new Point(10, 20) };
            btnHangar.Click += ShowHangarBay;

            radioNormal = new RadioButton { Text = "🟢 Normal Mode", Location = new Point(10, 80), Checked = true };
            radioCombat = new RadioButton { Text = "🔴 Combat Mode", Location = new Point(10, 110) };
            radioNormal.CheckedChanged += ShowCommandCenter;
            radioCombat.CheckedChanged += ShowCommandCenter;

            chkXRay = new CheckBox { Text = "X-Ray", Location = new Point(10, 160) };
            chkDefib = new CheckBox { Text = "Defibrillator", Location = new Point(10, 190) };
            chkTrauma = new CheckBox { Text = "Trauma Kit", Location = new Point(10, 220) };
            chkXRay.CheckedChanged += ShowMedicalBay;
            chkDefib.CheckedChanged += ShowMedicalBay;
            chkTrauma.CheckedChanged += ShowMedicalBay;

            cmbMealTime = new ComboBox { Location = new Point(10, 270), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbMealTime.Items.AddRange(new string[] { "Breakfast", "Lunch", "Dinner" });
            cmbMealTime.SelectedIndex = 0;
            cmbMealTime.SelectedIndexChanged += ShowMessDecks;

            trackOccupancy = new TrackBar { Minimum = 0, Maximum = 100, Value = 87, TickFrequency = 10, Width = 250, Location = new Point(10, 330) };
            trackOccupancy.Scroll += ShowSleepingQuarters;

            progressFuel = new ProgressBar { Minimum = 0, Maximum = 100, Value = 67, Width = 250, Location = new Point(10, 400) };
            progressFuel.Click += ShowEngineRoom;

            // BACK Button to return to intro screen
            btnBack = new Button
            {
                Text = "⬅ Back to Intro",
                Size = new Size(150, 40),
                Location = new Point(10, 500),
                BackColor = Color.LightCoral
            };
            btnBack.Click += (s, e) =>
            {
                this.Hide();                // Hide this enhanced form
                introFormRef.Show();        // Return to the original IntroForm
            };

            // Add everything to the form
            this.Controls.AddRange(new Control[]
            {
                btnHangar, radioNormal, radioCombat,
                chkXRay, chkDefib, chkTrauma,
                cmbMealTime, trackOccupancy, progressFuel,
                btnBack, mainPanel
            });
        }

        // MODULE LOGIC SECTION
        private void ShowHangarBay(object sender, EventArgs e) =>
            displayLabel.Text = "🚁 Hangar Bay\n\n- 3x CH-53E Helicopters\n- 2x AV-8B Harriers\n- Status: Green";

        private void ShowCommandCenter(object sender, EventArgs e)
        {
            string mode = radioNormal.Checked ? "Normal" : "Combat";
            string alert = radioNormal.Checked ? "DEFCON 5" : "DEFCON 2";
            displayLabel.Text = $"🧭 Command Center\n\nMode: {mode}\nAlert Level: {alert}";
        }

        private void ShowMedicalBay(object sender, EventArgs e)
        {
            displayLabel.Text = "🩺 Medical Bay Equipment:\n\n";
            if (chkXRay.Checked) displayLabel.Text += "- ✅ X-Ray operational\n";
            if (chkDefib.Checked) displayLabel.Text += "- ✅ Defibrillator ready\n";
            if (chkTrauma.Checked) displayLabel.Text += "- ✅ Trauma kit stocked\n";
            if (!chkXRay.Checked && !chkDefib.Checked && !chkTrauma.Checked)
                displayLabel.Text += "- ⚠️ No equipment selected.\n";
        }

        private void ShowMessDecks(object sender, EventArgs e)
        {
            string meal = cmbMealTime.SelectedItem.ToString();
            string menu = "";

            // ✅ C# 7.3-compatible switch statement
            switch (meal)
            {
                case "Breakfast": menu = "• Eggs, Toast, Juice"; break;
                case "Lunch": menu = "• Chicken Sandwich, Salad"; break;
                case "Dinner": menu = "• Pasta, Steak, Veggies"; break;
                default: menu = "• Standard Meal"; break;
            }

            displayLabel.Text = $"🍽️ Mess Deck - {meal}\n\nMenu:\n{menu}\n\n- Seating: 150 sailors\n- Supplies: 20 days";
        }

        private void ShowSleepingQuarters(object sender, EventArgs e) =>
            displayLabel.Text = $"🛏️ Sleeping Quarters\n\n- Occupancy: {trackOccupancy.Value}%";

        private void ShowEngineRoom(object sender, EventArgs e) =>
            displayLabel.Text = $"⚙️ Engine Room\n\n- Fuel: {progressFuel.Value}%\n- Temperature: Stable 230°F";
    }
}